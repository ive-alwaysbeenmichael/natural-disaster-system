using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Disaster
{
    public class IndexModel : PageModel
    {
        public List<disaster> disasterlist = new List<disaster>();
        public void OnGet()
        {
            //connection string class
            Utility util = new Utility();

            try
            {
                //declare sql connection
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    //open declared connection
                    con.Open();
                    //define sql query
                    String query = "SELECT * FROM disaster";
                    //declare and initialize sqlcommand using the query and the connection
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        //declare and execute sql reader using the command
                        using (SqlDataReader read = com.ExecuteReader())
                        {
                            //while loop runs for as long as the reader has things to read
                            while (read.Read())
                            {
                                disaster disaster = new disaster();
                                //assigning database values to the previosuly declared properties of an external class
                                disaster.d_name = read.GetString(1);
                                disaster.s_date = read.GetString(2);
                                disaster.e_date = read.GetString(3);
                                disaster.d_location = read.GetString(4);
                                disaster.d_description = read.GetString(5);
                                disaster.d_req_aid = read.GetString(6);
                                //add users opjects to the user list
                                disasterlist.Add(disaster);
                            }

                        }

                    }

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("App crashed due to " + ex.Message);
            }
        }
    }

    public class disaster
    {
        public string d_name;
        public string s_date;
        public string e_date;
        public string d_location;
        public string d_description;
        public string d_req_aid;
    }

}
