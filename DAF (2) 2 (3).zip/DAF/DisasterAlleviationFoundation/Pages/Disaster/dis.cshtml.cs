using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Disaster
{
    public class disModel : PageModel
    {
       public disaster disaster = new disaster();
       public string err = "";
       public string success = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {


            disaster disaster = new disaster();
            Utility util = new Utility();
           

            disaster.d_name = Request.Form["d_name"];
            disaster.s_date = Request.Form["s_date"];
            disaster.e_date = Request.Form["e_date"];
            disaster.d_location = Request.Form["d_location"];
            disaster.d_description = Request.Form["d_description"];
            disaster.d_req_aid = Request.Form["d_req_aid"];

            if (disaster.d_name.Length == 0 || disaster.s_date.Length == 0 || disaster.e_date.Length == 0
                || disaster.d_location.Length == 0 || disaster.d_description.Length == 0 || disaster.d_req_aid.Length == 0)
            {
                err = "No Fields Can Be Left Empty";
                return;
            }
            //save userdata
            try
            {
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    con.Open();
                    string query = "INSERT INTO disaster (d_name,s_date,e_date,d_location,d_description,d_req_aid)VALUES" +
                        "(@d_name,@s_date,@e_date,d_location,d_description,d_req_aid);";
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        com.Parameters.AddWithValue("@d_name", disaster.d_name);
                        com.Parameters.AddWithValue("@s_date", disaster.s_date);
                        com.Parameters.AddWithValue("@e_date", disaster.e_date);
                        com.Parameters.AddWithValue("@d_location", disaster.d_location);
                        com.Parameters.AddWithValue("@d_description", disaster.d_description);
                        com.Parameters.AddWithValue("@d_req_aid", disaster.d_req_aid);


                        com.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(err = ex.Message);
            }

            //inventory entry



            disaster.d_name = "";
            disaster.s_date = "";
            disaster.e_date = "";
            disaster.d_location = "";
            disaster.d_description = "";
            disaster.d_req_aid = "";

            success = "Donation Successfully Captured";

        }
    }

}
