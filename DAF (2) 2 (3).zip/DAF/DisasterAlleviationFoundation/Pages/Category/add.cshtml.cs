using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Category
{
    public class addModel : PageModel
    {

       public category category = new category();
       public Utility util = new Utility();
        public string err = "";
        public string success = "";
        public void OnPost()
        {



            category.c_category = Request.Form["category"];
           
            if (category.c_category.Length == 0)
            {
                err = "No Fields Can Be Left Empty";
                return;
            }
            //save userdata
            try
            {
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    con.Open();
                    string query = "INSERT INTO category (category)VALUES(@category);";
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
             
                        com.Parameters.AddWithValue("@category", category.c_category);
                      

                        com.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(err = ex.Message);
            }
}
        }
    }
