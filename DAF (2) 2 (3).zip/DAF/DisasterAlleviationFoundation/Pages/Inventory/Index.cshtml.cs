using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DisasterAlleviationFoundation.Pages.Inventory
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
