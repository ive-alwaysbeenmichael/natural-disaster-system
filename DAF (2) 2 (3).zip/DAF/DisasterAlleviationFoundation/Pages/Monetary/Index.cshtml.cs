using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Monetary
{
    public class IndexModel : PageModel
    {
        public List<money> monetarylist = new List<money>();
        //connection string class
        Utility util = new Utility();
        //money class
        money money = new money();
        public void OnGet()
        {
            try
            {
                //declare sql connection
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    //open declared connection
                    con.Open();
                    //define sql query
                    String query = "select * from monetary";
                    //declare and initialize sqlcommand using the query and the connection
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        //declare and execute sql reader using the command
                        using (SqlDataReader read = com.ExecuteReader())
                        {
                            //while loop runs for as long as the reader has things to read
                            while (read.Read())
                            {
                                //assigning database values to the previosuly declared properties of an external class
                                money.m_donor = read.GetString(1);
                                money.m_amount = read.GetString(2);
                                money.m_date = read.GetString(3);
                                //add users opjects to the user list
                                monetarylist.Add(money);
                            }

                        }

                    }

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("App crashed due to " + ex.Message);
            }
        }
    }
    public class money
    {
        public string m_donor;
        public string m_amount;
        public string m_date;
    }
}
