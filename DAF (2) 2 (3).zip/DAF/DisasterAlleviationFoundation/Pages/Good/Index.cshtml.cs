using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Good
{
    public class IndexModel : PageModel
    {
        public List<goods> goodslist = new List<goods>();
        public void OnGet()
        {
            Utility util = new Utility();

            try
            {
                //declare sql connection
                using (SqlConnection con1 = new SqlConnection(util.connection))
                {
                    //open declared connection
                    con1.Open();
                    //define sql query
                    String query = "SELECT * FROM goods;";
                    //declare and initialize sqlcommand using the query and the connection
                    using (SqlCommand com1 = new SqlCommand(query, con1))
                    {
                        //declare and execute sql reader using the command
                        using (SqlDataReader read = com1.ExecuteReader())
                        {
                            //while loop runs for as long as the reader has things to read
                            while (read.Read())
                            {
                                goods goods = new goods();
                                //assigning database values to the previosuly declared properties of an external class
                                goods.g_donor = read.GetString(1);
                                goods.g_number_of_goods = read.GetString(2);
                                goods.g_Date = read.GetString(3);
                                goods.g_category = read.GetString(4);
                                goods.g_description = read.GetString(5);

                                //add users opjects to the user list
                                goodslist.Add(goods);
                            }

                        }

                    }

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("App crashed due to " + ex.Message);
            }
        }
    }
    public class goods
    {
        public string g_donor;
        public string g_number_of_goods;
        public string g_Date;
        public string g_category;
        public string g_description;

    }
}
