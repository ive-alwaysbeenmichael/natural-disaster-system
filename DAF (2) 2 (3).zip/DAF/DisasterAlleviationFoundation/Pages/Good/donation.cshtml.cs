using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Good
{
    public class donationModel : PageModel
    {
        public goods goods = new goods();
        public string err = "";
        public string success = "";
        public void OnGet()
        {
        }

        public void OnPost()
        {


            goods goods = new goods();
            Utility util = new Utility();
            string err = "";
            string success = "";

            goods.g_donor = Request.Form["donor"];
            goods.g_number_of_goods = Request.Form["number_of_items"];
            goods.g_Date = Request.Form["g_date"];
            goods.g_category = Request.Form["category"];
            goods.g_description = Request.Form["g_description"];
            if (goods.g_donor.Length == 0 || goods.g_number_of_goods.Length == 0 || goods.g_Date.Length == 0 || goods.g_category.Length == 0 || goods.g_description.Length == 0)
            {
                err = "No Fields Can Be Left Empty";
                return;
            }
            //save userdata
            try
            {
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    con.Open();
                    string query = "INSERT INTO goods (g_donor,g_number_of_goods,g_Date,g_category,g_description)VALUES(@name,@number_of_items,@g_date,@category,@desc);";
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        com.Parameters.AddWithValue("@name", goods.g_donor);
                        com.Parameters.AddWithValue("@number_of_items", goods.g_number_of_goods);
                        com.Parameters.AddWithValue("@g_date", goods.g_Date);
                        com.Parameters.AddWithValue("@category", goods.g_category);
                        com.Parameters.AddWithValue("@desc", goods.g_description);

                        com.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(err = ex.Message);
            }


            goods.g_donor = "";
            goods.g_number_of_goods = "";
            goods.g_Date = "";
            goods.g_category = "";
            success = "Donation Successfully Captured";

        }
    }
}
