using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Assign
{
    public class MoneyModel : PageModel
    {
        public void OnGet()
        {
        }
        public void OnPost()
        {


            money money = new money();
            Utility util = new Utility();
            string err = "";
            string success = "";

            money.m_donor = Request.Form["m_donor"];
            money.m_amount = Request.Form["m_amount"];
            money.m_date = Request.Form["m_date"];

            if (money.m_donor.Length == 0 || money.m_amount.Length == 0 || money.m_date.Length == 0)
            {
                err = "No Fields Can Be Left Empty";
                return;
            }
            //save userdata
            try
            {
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    con.Open();
                    string query = "INSERT INTO monetary (m_donor,m_amount,m_date)VALUES(@name,@amount,@date);";
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        com.Parameters.AddWithValue("@name", money.m_donor);
                        com.Parameters.AddWithValue("@amount", money.m_amount);
                        com.Parameters.AddWithValue("@date", money.m_date);


                        com.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(err = ex.Message);
            }

            //inventory entry



            money.m_donor = "";
            money.m_amount = "";
            money.m_date = "";

            success = "Donation Successfully Captured";

        }
    }
}
