using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Users
{
    public class IndexModel : PageModel
    {   //list to store all database retrieved users
        public List<users> user = new List<users>();
        //connection string class
        Utility util = new Utility();
        //users class
        users users = new users();
        public void OnGet()
        {
            try
            {
                //declare sql connection
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    //open declared connection
                    con.Open();
                    //define sql query
                    String query = "SELECT * FROM users;";
                    //declare and initialize sqlcommand using the query and the connection
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        //declare and execute sql reader using the command
                        using (SqlDataReader read = com.ExecuteReader())
                        {
                            //while loop runs for as long as the reader has things to read
                            while (read.Read())
                            {
                                //assigning database values to the previosuly declared properties of an external class
                                users.uname = read.GetString(1);
                                users.uemail = read.GetString(2);
                                users.upassword = read.GetString(3);
                                users.utype = read.GetString(4);
                                //add users opjects to the user list
                                user.Add(users);
                            }

                        }

                    }

                }
            }
            catch (Exception ex)
            {

                Console.WriteLine("App crashed due to " + ex.Message);
            }
        }
    }
}
