using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data.SqlClient;

namespace DisasterAlleviationFoundation.Pages.Users
{
    public class LoginModel : PageModel
    {
        public users users = new users();
        public Utility util = new Utility();
        public string err = "";
        public string success = "";


        public void OnGet()
        {

        }

        public void OnPost()
        {
            //requestinf form data and reassigning it to the properties in the external class
            users.uemail = Request.Form["email"];
            users.upassword = Request.Form["password"];
            users.utype = Request.Form["type"];

            //not allowing any field to be left emptu
            if (users.uname.Length == 0 || users.uemail.Length == 0 || users.upassword.Length == 0 || users.utype.Length == 0)
            {
                err = "No Fields Can Be Left Empty";
                return;
            }
            //save userdata
            try
            {
                using (SqlConnection con = new SqlConnection(util.connection))
                {
                    string query = $"SELECT * FROM users WHERE email = '{users.uemail}' AND Upassword = '{users.upassword}';";
                    using (SqlCommand com = new SqlCommand(query, con))
                    {
                        using (SqlDataReader read = com.ExecuteReader())
                        {
                            while (read.Read())
                            {

                                users.uemail = read.GetString(2);
                                users.upassword = read.GetString(3);
                                if (users.uemail.Equals(Request.Form["email"]) && users.upassword.Equals(Request.Form["password"]))
                                {
                                    users.uemail = "";
                                    users.upassword = "";
                                    success = "User Successfully Logged in";
                                }
                                else
                                {
                                    err = "Check Credentials and try again";
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                Console.WriteLine(err = ex.Message);
            }


            users.uname = "";
            users.uemail = "";
            users.upassword = "";
            users.utype = "";
            success = "User Successfully Registered";

        }
    }
}
