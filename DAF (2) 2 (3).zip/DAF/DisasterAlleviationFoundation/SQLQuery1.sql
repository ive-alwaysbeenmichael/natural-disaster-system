﻿CREATE TABLE users 
(
ID int IDENTITY PRIMARY KEY NOT NULL,
uName VARCHAR (200),
uEmail VARCHAR (200),
uPassword VARCHAR(200),
uType VARCHAR(200)
);


CREATE TABLE goods 
(
ID int IDENTITY PRIMARY KEY NOT NULL,
g_donor VARCHAR (200),
g_number_of_goods varchar(200),
g_Date VARCHAR(200),
g_category VARCHAR(200),
g_description VARCHAR(200)
);

select * from monetary

CREATE TABLE monetary 
(
ID int IDENTITY PRIMARY KEY NOT NULL,
m_donor VARCHAR (200),
m_amount VARCHAR(200),
m_date VARCHAR(200)
);

insert into monetary(m_donor,m_amount,m_date) VALUES('demo','500','2020-11-02');

CREATE TABLE category 
(
ID int IDENTITY PRIMARY KEY NOT NULL,
category VARCHAR (200),
);

CREATE TABLE disaster 
(
ID int IDENTITY PRIMARY KEY NOT NULL,
d_name VARCHAR (200),
s_date VARCHAR (200),
e_date VARCHAR (200),
d_location VARCHAR(200),
d_description VARCHAR(200),
d_req_aid VARCHAR(200),
);

