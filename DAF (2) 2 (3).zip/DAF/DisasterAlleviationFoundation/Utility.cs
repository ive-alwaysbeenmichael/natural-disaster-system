﻿namespace DisasterAlleviationFoundation
{
    public class Utility
    {
        public String connection = "Data Source=DESKTOP-EA7SJUA\\SQLEXPRESS;Initial Catalog=DAF;Integrated Security=True";
    }

    public class users
    {

        public string uname { get; set; }
        public string uemail { get; set; }
        public string upassword { get; set; }
        public string utype { get; set; }

    }



    public class disaster
    {
        public string d_name;
        public string s_date;
        public string e_date;
        public string d_location;
        public string d_description;
        public string d_req_aid;
    }

    public class category
    {
        public string c_category;
    }


    public class inventory
    {
        public string i_qty;
        public string i_amt;
    }

    public class purchases
    {

    }
}
